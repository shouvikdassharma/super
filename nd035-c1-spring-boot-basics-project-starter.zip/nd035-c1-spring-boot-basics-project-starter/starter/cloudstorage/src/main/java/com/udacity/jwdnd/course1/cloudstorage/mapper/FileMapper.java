package com.udacity.jwdnd.course1.cloudstorage.mapper;

public interface FileMapper {
}
