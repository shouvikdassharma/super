package com.udacity.jwdnd.course1.cloudstorage.mapper;

import org.apache.ibatis.annotations.Mapper;


@Mapper
public interface NoteMapper {

}
